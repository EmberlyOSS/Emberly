# Emberly Media Kit

## About Emberly

Emberly is a developer-first, privacy-focused file sharing platform. This media kit contains official brand assets for press, partnerships, and promotional use.

## Contents

- `/logos/` - Logo files in various formats and sizes
- `/colors/` - Color palette documentation
- `/typography/` - Typography guidelines
- `/videos/` - Promotional video clips
- `BRAND_GUIDELINES.md` - Complete brand usage guidelines

## Quick Reference

### Brand Colors

| Color | Hex | RGB | Usage |
|-------|-----|-----|-------|
| Primary Orange | #F97316 | 249, 115, 22 | Brand color, CTAs, links |
| Background | #0A0A0B | 10, 10, 11 | Page backgrounds |
| Foreground | #FAFAFA | 250, 250, 250 | Primary text |
| Muted | #27272A | 39, 39, 42 | Subtle backgrounds |

### Typography

- **Font Family:** Inter
- **Headings:** Bold (700-800)
- **Body:** Regular (400)
- **UI Elements:** Medium (500)

### Logo Usage

- Always use official logos from this kit
- Maintain clear space around the logo
- Do not stretch, distort, or add effects
- Do not change brand colors

## Contact

- **Press inquiries:** press@embrly.ca
- **General inquiries:** hey@embrly.ca
- **GitHub:** https://github.com/EmberlyOSS

## License

These assets are provided for press and promotional use only. Please contact us for commercial licensing inquiries.

---

Generated on 2026-01-04
© 2026 Emberly. All rights reserved.
