# Emberly Brand Guidelines

## Brand Identity

### Mission
Emberly is a developer-first file sharing platform focused on privacy, simplicity, and reliability.

### Brand Personality
- **Professional** - Clean, modern, trustworthy
- **Developer-focused** - Technical but accessible
- **Privacy-conscious** - Security-first mindset
- **Open** - Transparent and community-driven

## Logo

### Primary Logo
The Emberly logo consists of a flame icon mark paired with the wordmark. Use the primary logo whenever possible.

### Icon Mark
The flame icon can be used alone for favicons, app icons, and small spaces where the full logo won't fit.

### Wordmark
The text-only version can be used in inline contexts or where the icon would be redundant.

### Clear Space
Maintain a minimum clear space around the logo equal to the height of the "E" in Emberly.

### Minimum Sizes
- Full logo: 120px wide minimum
- Icon only: 24px minimum
- Favicon: 16px minimum

### Don'ts
- ❌ Don't stretch or distort the logo
- ❌ Don't change the brand colors
- ❌ Don't add drop shadows, gradients, or effects
- ❌ Don't place on busy or low-contrast backgrounds
- ❌ Don't rotate or flip the logo
- ❌ Don't outline or add strokes

## Color Palette

### Primary Colors

#### Primary Orange
- **Hex:** #F97316
- **RGB:** 249, 115, 22
- **HSL:** 24.6 95% 53.1%
- **Usage:** Primary brand color, call-to-action buttons, links, accents

### UI Colors (Dark Theme)

#### Background
- **Hex:** #0A0A0B
- **RGB:** 10, 10, 11
- **Usage:** Page backgrounds, base surfaces

#### Foreground
- **Hex:** #FAFAFA
- **RGB:** 250, 250, 250
- **Usage:** Primary text, headings

#### Muted
- **Hex:** #27272A
- **RGB:** 39, 39, 42
- **Usage:** Secondary backgrounds, borders, subtle elements

#### Card
- **Hex:** #0A0A0B
- **RGB:** 10, 10, 11
- **Usage:** Card surfaces, elevated elements

## Typography

### Font Family
**Inter** - A highly legible typeface designed for screens.

Available free from [Google Fonts](https://fonts.google.com/specimen/Inter).

### Font Weights

| Usage | Weight | Size |
|-------|--------|------|
| Page Titles | Bold (700-800) | 32-48px |
| Section Headers | Semibold (600) | 24-32px |
| Body Text | Regular (400) | 14-16px |
| UI Labels | Medium (500) | 12-14px |
| Captions | Regular (400) | 12px |

### Line Heights
- Headings: 1.2 - 1.3
- Body text: 1.5 - 1.6
- UI elements: 1.4

## Voice & Tone

### How to describe Emberly
- Developer-first file sharing platform
- Privacy-focused and open source
- Self-hostable with modern architecture
- Simple, fast, and reliable

### Writing Style
- Clear and concise
- Technical but accessible
- Friendly but professional
- Action-oriented

### Naming Conventions
- Always capitalize: **Emberly**
- Don't abbreviate or stylize (not "EMBERLY" or "emberly")
- Reference the project, not "the Emberly team"
- Use "Emberly" alone, not "Emberly app" or "Emberly service"

## Contact

For brand-related questions or custom asset requests:

- **Press:** press@embrly.ca
- **General:** hey@embrly.ca
- **GitHub:** https://github.com/EmberlyOSS

---

© 2026 Emberly. All rights reserved.
