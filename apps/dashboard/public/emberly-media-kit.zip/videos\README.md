# Promotional Videos

## Contents

- **site-preview-ad.mp4** - Quick overview of the Emberly interface and main features (~15s)
- **uploading-ad.mp4** - Demonstration of the seamless file upload experience (~10s)

## Usage

These videos can be used for:
- Social media posts and ads
- Press coverage and articles
- Presentations and demos
- Partner promotional materials

## Technical Specs

- Format: MP4 (H.264)
- Resolution: 1920x1080 (1080p)
- Frame Rate: 30fps
- Audio: None (silent)

## Attribution

Please credit "Emberly" when using these videos in publications.
