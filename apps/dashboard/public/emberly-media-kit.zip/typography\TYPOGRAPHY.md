# Emberly Typography

## Font Family

### Inter

Inter is a carefully crafted open-source typeface designed for high legibility on computer screens.

**Download:** [Google Fonts](https://fonts.google.com/specimen/Inter)

## Font Stack

```css
font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
```

## Type Scale

| Element | Size | Weight | Line Height |
|---------|------|--------|-------------|
| Display | 48px / 3rem | 800 | 1.1 |
| H1 | 36px / 2.25rem | 700 | 1.2 |
| H2 | 30px / 1.875rem | 700 | 1.25 |
| H3 | 24px / 1.5rem | 600 | 1.3 |
| H4 | 20px / 1.25rem | 600 | 1.35 |
| Body Large | 18px / 1.125rem | 400 | 1.6 |
| Body | 16px / 1rem | 400 | 1.5 |
| Body Small | 14px / 0.875rem | 400 | 1.5 |
| Caption | 12px / 0.75rem | 400 | 1.4 |
| UI Label | 14px / 0.875rem | 500 | 1.4 |

## Usage Examples

### Headings

```css
h1 {
  font-size: 2.25rem;
  font-weight: 700;
  line-height: 1.2;
  letter-spacing: -0.025em;
}
```

### Body Text

```css
p {
  font-size: 1rem;
  font-weight: 400;
  line-height: 1.5;
}
```

### UI Elements

```css
.button {
  font-size: 0.875rem;
  font-weight: 500;
  line-height: 1.4;
}
```
