# Logo Files

## icon.svg
The primary Emberly flame icon in SVG format. Scalable to any size.

## banner.png
The Emberly banner image for Open Graph and social media previews.

## Recommended Sizes

| Use Case | Size |
|----------|------|
| Favicon | 16x16, 32x32 |
| App Icon | 64x64, 128x128, 256x256, 512x512 |
| Social Media | 400x400 |
| Banner | 1200x630 |

## File Formats

- **SVG** - Vector format, use for web and print
- **PNG** - Raster format with transparency, use when SVG not supported
