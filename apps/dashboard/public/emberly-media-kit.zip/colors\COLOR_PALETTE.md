# Emberly Color Palette

## Primary Brand Color

### Orange (#F97316)
The primary brand color representing energy, creativity, and warmth.

```css
--primary: 24.6 95% 53.1%;
```

| Format | Value |
|--------|-------|
| Hex | #F97316 |
| RGB | 249, 115, 22 |
| HSL | 24.6, 95%, 53.1% |

## Dark Theme Colors

### Primary Orange

| Format | Value |
|--------|-------|
| Hex | #F97316 |
| RGB | 249, 115, 22 |
| HSL | 24.6 95% 53.1% |

### Accent

| Format | Value |
|--------|-------|
| Hex | #F97316 |
| RGB | 249, 115, 22 |
| HSL | 24.6 95% 53.1% |

### Background

| Format | Value |
|--------|-------|
| Hex | #0A0A0B |
| RGB | 10, 10, 11 |
| HSL | 240 10% 3.9% |

### Foreground

| Format | Value |
|--------|-------|
| Hex | #FAFAFA |
| RGB | 250, 250, 250 |
| HSL | 0 0% 98% |

### Muted

| Format | Value |
|--------|-------|
| Hex | #27272A |
| RGB | 39, 39, 42 |
| HSL | 240 3.7% 15.9% |

### Card

| Format | Value |
|--------|-------|
| Hex | #0A0A0B |
| RGB | 10, 10, 11 |
| HSL | 240 10% 3.9% |

## CSS Variables

```css
:root {
  --primary: 24.6 95% 53.1%;
  --primary-foreground: 60 9.1% 97.8%;
  --background: 240 10% 3.9%;
  --foreground: 0 0% 98%;
  --card: 240 10% 3.9%;
  --card-foreground: 0 0% 98%;
  --muted: 240 3.7% 15.9%;
  --muted-foreground: 240 5% 64.9%;
  --accent: 240 3.7% 15.9%;
  --accent-foreground: 0 0% 98%;
  --border: 240 3.7% 15.9%;
}
```
